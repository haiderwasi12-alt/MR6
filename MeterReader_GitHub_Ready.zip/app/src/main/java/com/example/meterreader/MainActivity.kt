package com.example.meterreader

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.example.meterreader.databinding.ActivityMainBinding
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var executor: ExecutorService
    private var imageCapture: ImageCapture? = null

    private val permission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok ->
        if (ok) startCamera()
        else binding.statusText.text = "Camera permission is required."
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        executor = Executors.newSingleThreadExecutor()
        binding.captureButton.setOnClickListener { captureAndRead() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else permission.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also {
                it.surfaceProvider = binding.previewView.surfaceProvider
            }
            imageCapture = ImageCapture.Builder().build()
            try {
                provider.unbindAll()
                provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture
                )
            } catch (e: Exception) {
                binding.statusText.text = "Camera error: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun captureAndRead() {
        val capture = imageCapture ?: return
        binding.captureButton.isEnabled = false
        binding.statusText.text = "Reading meter..."

        capture.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(proxy: ImageProxy) {
                val media = proxy.image
                if (media == null) {
                    proxy.close()
                    return
                }
                val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                val recognizer = TextRecognition.getClient(
                    TextRecognizerOptions.DEFAULT_OPTIONS
                )
                recognizer.process(image)
                    .addOnSuccessListener { result ->
                        val reading = extractDigits(result.text)
                        runOnUiThread {
                            if (reading.isNotEmpty()) {
                                binding.readingEditText.setText(reading)
                                binding.statusText.text =
                                    "Reading detected. Check and correct it if needed."
                            } else {
                                binding.statusText.text =
                                    "No digits detected. Try again with better light."
                            }
                            binding.captureButton.isEnabled = true
                        }
                    }
                    .addOnFailureListener {
                        runOnUiThread {
                            binding.statusText.text = "OCR failed. Please try again."
                            binding.captureButton.isEnabled = true
                        }
                    }
                    .addOnCompleteListener {
                        proxy.close()
                        recognizer.close()
                    }
            }

            override fun onError(e: ImageCaptureException) {
                runOnUiThread {
                    binding.captureButton.isEnabled = true
                    binding.statusText.text = "Capture failed. Please try again."
                }
            }
        })
    }

    private fun extractDigits(text: String): String {
        val normalized = text.uppercase()
            .replace('O','0').replace('I','1').replace('L','1')
            .replace('S','5').replace('B','8').replace('G','6')
        return normalized.split(Regex("[^0-9]+"))
            .filter { it.length >= 2 }
            .maxByOrNull { it.length } ?: ""
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
