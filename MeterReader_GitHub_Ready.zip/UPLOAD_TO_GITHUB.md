# GitHub upload

IMPORTANT: This folder is already in the correct Android project structure.

Upload the CONTENTS of this folder to the ROOT of your GitHub repository.

The repository root must directly contain:
- app/
- .github/
- build.gradle.kts
- settings.gradle.kts
- gradle.properties

Do NOT upload the parent folder itself as a nested folder.
Do NOT upload this project as a ZIP if you want GitHub Actions to build it directly.
